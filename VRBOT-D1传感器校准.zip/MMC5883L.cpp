
#include "MMC5883L.H"
//

SoftI2CMaster i2c(sdaPin,sclPin);
static bool start = true;
int offsetY,offsetX;
float coefficientX;
int CompassSenorInit()
{
    i2c.beginTransmission(ADDRESS);
    i2c.send(MMC5883MA_REG_CTRL0);
    i2c.send(MMC5883MA_CMD_SET);
    i2c.endTransmission();
    delay(1);
    i2c.beginTransmission(ADDRESS);
    i2c.send(MMC5883MA_REG_CTRL0);
    i2c.send(MMC5883MA_CMD_TM_M);
    i2c.endTransmission();
    /*Read Eeprom*/
    EepromRead(CompassOffsetY,&offsetY,sizeof(offsetY));
    EepromRead(CompassOffsetX,&offsetX,sizeof(offsetX));
    EepromRead(CompassCoefficientX,&coefficientX,sizeof(coefficientX));
    Serial.print("CompassInit!  ");
    Serial.print("   offsetX：");
    Serial.print(offsetX);
    Serial.print("   offsetY：");
    Serial.print(offsetY);
    Serial.print("   coefficientX:");
    Serial.println(coefficientX);
  }


int calculateHeading(int* x ,int* y)  
{  
    float headingRadians = atan2((double)((*y)),(double)((*x)));  
    // 保证数据在0-2*PI之间  
    if(headingRadians < 0)  
    headingRadians += 2*PI;  
    
    int headingDegrees = headingRadians * 180/M_PI;  
    headingDegrees += MagnetcDeclination; //磁偏角  
    
    // <span style="font-family: Arial, Helvetica, sans-serif;">保证数据在0-360之间</span>  
    if(headingDegrees > 360)  
    headingDegrees -= 360;  
    
    return headingDegrees;  
} 

float CompassSenorDetect()
{
    int x,y,z;
    uint16_t tempx,tempy;
    static int time = millis();
    
    i2c.beginTransmission(ADDRESS);
    i2c.send(MMC5883MA_REG_CTRL0);
    i2c.send(MMC5883MA_CMD_SET);
    i2c.endTransmission();
    delay(1);
    i2c.beginTransmission(ADDRESS);
    i2c.send(MMC5883MA_REG_CTRL0);
    i2c.send(MMC5883MA_CMD_TM_M);
    i2c.endTransmission();
    delay(1);
    
    i2c.beginTransmission(ADDRESS);
    i2c.send(0x00); //select register 3, X MSB register
    i2c.endTransmission();
    i2c.requestFrom(ADDRESS);
    
    tempx = i2c.receive(); //X msb
    tempx |= i2c.receive()<<8; //X lsb
    tempy = i2c.receive(); //Z msb
    tempy |= i2c.receiveLast()<<8; //Z lsb
    
    x = (tempx - 32768 - offsetX); //* coefficientX;
    y = tempy - 32768 - offsetY;
    
    
    i2c.beginTransmission(ADDRESS);
    i2c.send(MMC5883MA_REG_CTRL0);
    i2c.send(MMC5883MA_CMD_TM_M);
    i2c.endTransmission();
    float angle = calculateHeading(&x,&y);
    #if 1 
    Serial.print("tempx: ");
    Serial.print(tempx);
    Serial.print(";tempy: ");
    Serial.print(tempy);
    
    
    Serial.print(";x: ");
    Serial.print(x);
    Serial.print("  ;y: ");
    Serial.print(y);
    Serial.print(" ;angle(x,y): ");  
    Serial.println(angle);//输出x,y平面方向角  
    #endif
    return angle;
  }

int CompassSenorCalibration()
{
  
    int x,y;
    static int yMax,yMin,xMax,xMin ;
    uint16_t tempx,tempy;
    static uint8_t count = 0;
    static int time = millis();
    Serial.println("CompassCalibration!!");
    while(millis()-time < 10000){
        
        i2c.beginTransmission(ADDRESS);
        i2c.send(MMC5883MA_REG_CTRL0);
        i2c.send(MMC5883MA_CMD_SET);
        i2c.endTransmission();
        delay(1);
        i2c.beginTransmission(ADDRESS);
        i2c.send(MMC5883MA_REG_CTRL0);
        i2c.send(MMC5883MA_CMD_TM_M);
        i2c.endTransmission();
        delay(1);
        
        i2c.beginTransmission(ADDRESS);
        i2c.send(0x00); //select register 3, X MSB register
        i2c.endTransmission();
        i2c.requestFrom(ADDRESS);
        
        tempx = i2c.receive(); //X msb
        tempx |= i2c.receive()<<8; //X lsb
        tempy = i2c.receive(); //Z msb
        tempy |= i2c.receiveLast()<<8; //Z lsb
        
        x = tempx - 32768;
        y = tempy - 32768;
        
        
        if(start){
            xMin = xMax = x;
            yMin = yMax = y;
            start = false;
        }
        xMax = (x > xMax) ? x : xMax;
        xMin = (x < xMin) ? x : xMin;
        yMax = (y > yMax) ? y : yMax;
        yMin = (y < yMin) ? y : yMin;
        
        i2c.beginTransmission(ADDRESS);
        i2c.send(MMC5883MA_REG_CTRL0);
        i2c.send(MMC5883MA_CMD_TM_M);
        i2c.endTransmission();
        
    }
    offsetX = (xMax + xMin)/2;
    offsetY = (yMax + yMin)/2;
    coefficientX = abs((float)(yMax - yMin) / (xMax - xMin));
    EepromWrite(CompassOffsetX,&offsetX,sizeof(offsetX));
    EepromWrite(CompassOffsetY,&offsetY,sizeof(offsetY));
    EepromWrite(CompassCoefficientX,&coefficientX,sizeof(coefficientX));
    
    Serial.print("xMax : ");
    Serial.print(xMax);
    Serial.print("    xMin : ");
    Serial.print(xMin);
    Serial.print("    yMax : ");
    Serial.print(yMax);
    Serial.print("    yMin : ");
    Serial.println(yMin);
    
    Serial.print("offsetX : ");
    Serial.print(offsetX);
    Serial.print("    offsetY : ");
    Serial.print(offsetY);
    Serial.print("    coefficientX : ");
    Serial.println(coefficientX);
}

  

