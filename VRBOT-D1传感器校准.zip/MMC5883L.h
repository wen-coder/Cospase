#include "arduino.h"
#include "SoftI2CMaster.h"
#include"E2PROM.h"

#define ADDRESS 0x30 //
#define MagnetcDeclination 2 //笔者所在地磁偏角，请根据情况自行百度  
#define CalThreshold 0  
   

#define MMC5883MA_REG_DATA      0x00
#define MMC5883MA_REG_TEMP      0x06
#define MMC5883MA_REG_STATUS    0x07
#define MMC5883MA_REG_CTRL0     0x08
#define MMC5883MA_REG_CTRL1     0x09
#define MMC5883MA_REG_CTRL2     0x0A
#define MMC5883MA_REG_PRODUCTID   0x2F
 
#define MMC5883MA_CMD_RESET         0x10
#define MMC5883MA_CMD_SET     0x08
#define MMC5883MA_CMD_TM_M      0x01
#define MMC5883MA_CMD_TM_T      0x02
#define MMC5883MA_PRODUCT_ID    0x0C

#define OFFSETX   1669
#define OFFSETY   -12649 
#define XCOE      1.05
 


typedef enum{
    CompassBase = 290,
    CompassOffsetX = CompassBase + 0,
    CompassOffsetY = CompassBase + 2,
    CompassCoefficientX = CompassBase + 4,
  }compassAddress;

extern int CompassSenorInit();
extern float CompassSenorDetect();
extern int CompassSenorCalibration();
