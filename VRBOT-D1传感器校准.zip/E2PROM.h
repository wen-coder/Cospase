#include <EEPROM.h>
#include"arduino.h"

/*250+4*6 = 274*/


  /*eeprom*/
extern void Eeprom(void);
extern void EepromWrite(int add,float* var,int len);
extern void EepromRead(int add,float* var,int len);
extern void EepromWrite(int add,int* var,int len);
extern void EepromRead(int add,int* var,int len);
