#include"IRModule.h"
#include"arduino.h"
int IRInit()
{
    pinMode(IRPIN1,INPUT);  
    pinMode(IRPIN2,INPUT);
    pinMode(IRPIN3,INPUT);
    pinMode(IRPIN4,INPUT);
    pinMode(IRPIN5,INPUT);
    pinMode(IRPIN6,INPUT);
}


int IRDetectPort(int port)
{
    switch(port){
        case IR1:
            return digitalRead(IRPIN1);
        break;
        case IR2:
            return digitalRead(IRPIN2);
        break;
        case IR3:
            return digitalRead(IRPIN3);
        break;
        case IR4:
            return digitalRead(IRPIN4);
        break;
        case IR5:
            return digitalRead(IRPIN5);
        break;
        case IR6:
            return digitalRead(IRPIN6);
        break;
    }
}
int IRDetect()
{
    int val;
    val |= digitalRead(IRPIN1)<<0;
    val |= digitalRead(IRPIN2)<<1;
    val |= digitalRead(IRPIN3)<<2;
    val |= digitalRead(IRPIN4)<<3;
    val |= digitalRead(IRPIN5)<<4;
    val |= digitalRead(IRPIN6)<<5;
    return val;
}
