/****************************************Copyright(c)*****************************************************
**                            Shenzhen Yuejiang Technology Co., LTD.
**
**                                 http://www.dobot.cc
**
**--------------File Info---------------------------------------------------------------------------------
** File name:           Dobot.cpp
** Latest modified Date:2017-11.2
** Latest Version:      V0.9.0
** Descriptions:        SmartBot Api
**
**--------------------------------------------------------------------------------------------------------
** Created by:          Edward
** Created date:        2017-8-15
** Version:             V1.0.0
** Descriptions:        Mixly API
**--------------------------------------------------------------------------------------------------------
*********************************************************************************************************/
#include "arduino.h"
#include "Beep.h"
#include "HC-SR04.h"
#include "IRModule.h"
#include "MMC5883L.H"
#include "Motor.h"
#include "TCS3200.h"                                                                                                                                                                                                                                                                                                                             
#include "TimerOne.h"
#include <EEPROM.h>
#include"E2PROM.h"
/*key*/
#define PINSW3   37
#define PINSW2   36
#define PINSW1   35  
/*LED*/
#define LED1    12 
#define LED2    13
/*Battery*/
#define BATTERYPIN   A12
#define LOWPOWER     (3/5)*1024

#define VERSIONADD  212
extern int gHWVersion ;
typedef struct{
   int bias;
   int lastBias;
   int current;
   int target;
   int pwm;
}PIParams;


enum{
    SW1,
    SW2,
    SW3
  };
/*Light*/
#define  LIGHT  A8

/*Movement*/
enum{
  FRONT,
  BACK,
  RIGHT,
  LEFT
  };

  
enum{
  MOTORR,
  MOTORL
  };
  
enum{
    POWER,
    SPEED
  };
  
enum{
    ON,
    OFF,
    BLINK 
};


/**/
extern float  kp,ki;
extern bool LED1state,LED1state ;
extern int SmartBotSetTimeOneMs();
extern int TimeTask();
/*******************SmartBotInit*****************/
/*********************************************************************************************************
** Function name:       SmartBotInit
** Descriptions:        Init SmartBot Scource
** Input parameters:    none
** Output parameters:   none
** Returned value:      none
*********************************************************************************************************/
extern int SmartBotInit();
/*********************************************************************************************************
** Function name:       SmartBotSetMovment
** Descriptions:        Set Movement Direction and Speed
** Input parameters:    int dir(FRONT,BACK,RIGHT,LEFT),int speed(value<=255)
** Output parameters:   none
** Returned value:      none
*********************************************************************************************************/
extern int SmartBotSetMovment(int dir,int speed);
/*********************************************************************************************************
** Function name:       SmartBotSetMotor
** Descriptions:        Set Motor R&L
** Input parameters:    int port(MOTORR,MOTORL),int Power(value<=255)
** Output parameters:   none
** Returned value:      none
*********************************************************************************************************/
extern int SmartBotSetMotor(int mode,int port,int speed);
/*********************************************************************************************************
** Function name:       SmartBotSetMotorPI
** Descriptions:        Set Motor PI
** Input parameters:    float KP,float KI
** Output parameters:   none
** Returned value:      none
*********************************************************************************************************/
extern int SmartBotSetMotorPI(float KP,float KI);
/*********************************************************************************************************
** Function name:       SmartBotSetMotorSpeed
** Descriptions:        Set Motor R&L
** Input parameters:    int mode(SPEED、POWER),int port(MOTORR,MOTORL),int speed(<60mm/s in SPEED or <255 in POWER)
** Output parameters:   none
** Returned value:      none
*********************************************************************************************************/

extern float SmartBotGetMotorPose(int port);
/*********************************************************************************************************
** Function name:       SmartBotSetSonar
** Descriptions:        Set Sonar Init
** Input parameters:    int port(SONAR1,SONAR2,SONAR3)
** Output parameters:   none
** Returned value:      none
*********************************************************************************************************/
extern int SmartBotSetSonar(int port);
/*********************************************************************************************************
** Function name:       SmartBotGetSonar
** Descriptions:        Get Snoar Distance
** Input parameters:    int port(SONAR1,SONAR2,SONAR3)
** Output parameters:   none
** Returned value:      (float)Distance
*********************************************************************************************************/
extern float SmartBotGetSonar(int port);
/*********************************************************************************************************
** Function name:       SmartBotGetIRModulePort
** Descriptions:        Get IRModule Port valuwe
** Input parameters:    int port(IR1,IR2,IR3,IR4,IR5,IR6)
** Output parameters:   none
** Returned value:      valure
*********************************************************************************************************/
extern int SmartBotGetIRModulePort(int port);
/*********************************************************************************************************
** Function name:       SmartBotGetIRModulePort
** Descriptions:        Get IRModule valuwe
** Input parameters:    none
** Output parameters:   none
** Returned value:      valure(bit0-6 to IR1-6)
*********************************************************************************************************/
extern int SmartBotGetIRModuleValue();
/*********************************************************************************************************
** Function name:       SmartBotGetCompass
** Descriptions:        Get Compass Angle
** Input parameters:    none
** Output parameters:   none
** Returned value:      Angle
*********************************************************************************************************/
extern float SmartBotGetCompass();
/*********************************************************************************************************
** Function name:       SmartBotSetCompassCalibration
** Descriptions:        Set Calibration
** Input parameters:    none
** Output parameters:   none
** Returned value:      none
*********************************************************************************************************/
extern  void SmartBotSetCompassCalibration();
/*********************************************************************************************************
** Function name:       SmartBotSetColorWB
** Descriptions:        Set ColorSenor White Balance
** Input parameters:    int port(COLORSENOR1,COLORSENOR2)
** Output parameters:   none
** Returned value:      none
*********************************************************************************************************/
extern int SmartBotSetColorWB(int port);
/*********************************************************************************************************
** Function name:       SmartBotSetColorSenor
** Descriptions:        Set ColorSenor Init or Deinit
** Input parameters:    int port(COLORSENOR1,COLORSENOR2),bool ison(true,false)
** Output parameters:   none
** Returned value:      none
*********************************************************************************************************/
extern int SmartBotSetColorSenor(int port,bool ison);
/*********************************************************************************************************
** Function name:       SmartBotGetColorSenor
** Descriptions:        Get ColorSenor Value
** Input parameters:    int port(COLORSENOR1,COLORSENOR2),int color(RCOLOR,GCOLOR,BCOLOR)
** Output parameters:   none
** Returned value:      Color Value
*********************************************************************************************************/
extern int SmartBotGetColorSenor(int port,int color);
/*********************************************************************************************************
** Function name:       SmartBotSetKeyInit
** Descriptions:        Set Key Init
** Input parameters:    none
** Output parameters:   none
** Returned value:      none
*********************************************************************************************************/
extern int SmartBotSetKeyInit();
/*********************************************************************************************************
** Function name:       SmartBotGetKeyValue
** Descriptions:        Get Key Value
** Input parameters:    int key(PINSW1,PINSW2,PINSW3)
** Output parameters:   none
** Returned value:      none
*********************************************************************************************************/
extern int SmartBotGetKeyValue(int key);
/*********************************************************************************************************
** Function name:       SmartBotGetLightAnalog
** Descriptions:        Get Photoresistance Value
** Input parameters:    none
** Output parameters:   none
** Returned value:      Photoresistance Value 
*********************************************************************************************************/
extern int SmartBotGetLightAnalog();
/*********************************************************************************************************
** Function name:       SmartBotSetLED
** Descriptions:        SetLED
** Input parameters:    port(LED1/LED2),state(ON/OFF/BLINK)
** Output parameters:   none
** Returned value:      none
*********************************************************************************************************/
extern int SmartBotSetLED(int port,int state);
/*********************************************************************************************************
** Function name:       SmartBotSetSonarThreshold
** Descriptions:        SetSonarThreshold
** Input parameters:    int dis(mm)
** Output parameters:   none
** Returned value:      none
*********************************************************************************************************/
extern int SmartBotSetSonarThreshold(int dis);



