/****************************************Copyright(c)*****************************************************
**                            Shenzhen Yuejiang Technology Co., LTD.
**
**                                 http://www.dobot.cc
**
**--------------File Info---------------------------------------------------------------------------------
** File name:           Dobot.cpp
** Latest modified Date:2017-11.2
** Latest Version:      V0.9.0
** Descriptions:        SmartBot Api
**
**--------------------------------------------------------------------------------------------------------
** Created by:          Edward
** Created date:        2017-8-15
** Version:             V1.0.0
** Descriptions:        Mixly API
**--------------------------------------------------------------------------------------------------------
*********************************************************************************************************/
#include "SmartBot.h"
/*********************************************************************************************************
** Descriptions:        Put the global variable here
*********************************************************************************************************/
/*LED */
int gLED1State,gLED2State;
bool LED1state ,LED2state;
int gBlinkFre ;//Per 50ms
bool promgramRun = false;
/*mMotro*/
bool gSpeedMode;
int gMotorRSpeed,gMotorLSpeed;
PIParams gPIR,gPIL;

/*PI params*/
//float  kp = 3.5,ki = 1;
float  kp = 1,ki = 0.3;

/**/
int gPRMR;
int gPRML;

/*********************************************************************************************************
** Function name:       MotorPI
** Descriptions:        PI Control
** Input parameters:    none
** Output parameters:   none
** Returned value:      none
*********************************************************************************************************/
int MotorPI(PIParams *pi) 
{ 
    pi->bias = pi->target - pi->current ;
    pi->pwm += kp*(pi->bias - pi->lastBias) + ki * pi->bias;
    pi->lastBias = pi->bias;
    if(pi->pwm>255){
        pi->pwm = 255;
    }
    if(pi->pwm<-255){
        pi->pwm = -255;
    }
    return pi->pwm;
}
/*********************************************************************************************************
** Function name:       MotorPI
** Descriptions:        PI Control
** Input parameters:    none
** Output parameters:   none
** Returned value:      none
*********************************************************************************************************/
int LEDControl(void) 
{ 
    switch(gLED1State){
        case ON:
            LED1state = LOW;
        break;
        case OFF:
            LED1state = HIGH;
        break;
        case BLINK:
            LED1state = !LED1state;
        break;
        default:
        break;
    }
    
    switch(gLED2State){
        case ON:
            LED2state = LOW;
        break;
        case OFF:
            LED2state = HIGH;
        break;
        case BLINK:
            LED2state = !LED2state;
        break;
        default:
        break;
    }
    digitalWrite(LED1,LED1state);
    digitalWrite(LED2,LED2state);
    return 0;
}
////////////////////////////////////////////////////InitVariable//////////////////////////////////////////
/*********************************************************************************************************
** Function name:       InitVariable
** Descriptions:        
** Input parameters:    none
** Output parameters:   none
** Returned value:      none
*********************************************************************************************************/
int InitVariable(void)
{
    /*LED*/
    gLED1State = OFF;
    gLED2State = OFF;
    gBlinkFre = 10;
    
    /*Motor*/
    gSpeedMode = false;
    gPIR.pwm = 0;
    gPIL.pwm = 0;
    gPIR.current = 0;
    gPIL.current = 0;
    gPIR.target = 0;
    gPIL.target = 0;
    gPIR.bias = 0;
    gPIL.bias = 0;
    gPIR.lastBias = 0;
    gPIL.lastBias = 0;
    
    return 0;
}
void(* resetFunc) (void) = 0;//declare reset function at address 0c
////////////////////////////////////////////////////TimeOne//////////////////////////////////////////////
/*********************************************************************************************************
** Function name:       SmartBotSetTimeOneMs
** Descriptions:        Time task for ColorSensor & Motor pose
** Input parameters:    none
** Output parameters:   none
** Returned value:      none
*********************************************************************************************************/
int TimeTask()
{ 
    static int ledcount = 0,count = 0;
	static bool lowpower;
    if(count > 10 ){
        /*Battery*/
		uint16_t power = analogRead(A12);
		if(power > ((3.8 / 5.2) * 1024)){
			lowpower = false;
		}else if(analogRead(A12) < ((3.6 / 5.2) * 1024)){
			lowpower = true;
		}
		if(lowpower){
            digitalWrite(38, LOW);
        }else{
            digitalWrite(38, HIGH);
        }
        /*LED*/
        if(ledcount > gBlinkFre){
            
            LEDControl();
            ledcount = 0;
        }
        ledcount++;
        /*Motor*/
        if(gSpeedMode == true){
            MotorR(MotorPI(&gPIR));
            MotorL(MotorPI(&gPIL));
        }
		#if 0 	//20 subdiv
		gPIR.current = (gCounterR - gLastCounterR) * 4.61; //(60 * 1000)  / (260 * 50) = 2.051;
        gPIL.current = (gCounterL - gLastCounterL) * 4.61; //(60 * 1000)  / (260 * 50)= 2.051;	
		#else 	//45 subdiv
		gPIR.current = (gCounterR - gLastCounterR) * 2.051; //(60 * 1000)  / (585 * 50) = 2.051;
        gPIL.current = (gCounterL - gLastCounterL) * 2.051; //(60 * 1000)  / (585 * 50)= 2.051;	
		#endif
		
		
		 gPIR.current = gPRMR ;
		 gPIL.current = gPRML ;
		
        gLastCounterR = gCounterR ;
        gLastCounterL = gCounterL;
		
		
        count = 0;
    }
    /*Color*/
    ColorDetectCallBack1();
    ColorDetectCallBack2();
    /*PromgramReset*/
   
    count++;
    
}
/*********************************************************************************************************
** Function name:       SmartBotSetTimeOneMs
** Descriptions:        Set Time Intrrupt
** Input parameters:    none
** Output parameters:   none
** Returned value:      none
*********************************************************************************************************/

int SmartBotSetTimeOneMs()    //ms
{
    Timer1.initialize(5000); // 初始化,  interval 以 us 為單位
    Timer1.attachInterrupt(TimeTask); // attach the service routine here
}
//////////////////////////////////////////////////SmartBotInit////////////////////////////////////////////
/*********************************************************************************************************
** Function name:       SmartBotInit
** Descriptions:        Init SmartBot Scource
** Input parameters:    none
** Output parameters:   none
** Returned value:      none
*********************************************************************************************************/
int SmartBotInit()
{
    Serial.begin(115200);
    Serial2.begin(57600);   //Xbee
    
    pinMode(LED1, OUTPUT);        //LED1
    pinMode(LED2, OUTPUT);        //LED2
    SmartBotSetLED(LED1,OFF);
    SmartBotSetLED(LED2,OFF);
    BeepInit(); 
    SmartBotSetTimeOneMs();

    MotorInit();
    EncoderInit();
	
    SmartBotSetKeyInit();
    static bool releasedFlag = true;
    while(!promgramRun){
        if(!digitalRead(37)){
            delay(20);
            if(!digitalRead(37)){
                releasedFlag = false;
            }
        }
        if(!releasedFlag){
            if(digitalRead(37)){
                promgramRun = true;
            }
        }
    }
    SmartBotSetLED(LED1,OFF);
    Serial.println("ProgramStar:");
    /*InitVariable*/
    InitVariable();
    BeepInit();  
    SmartBotSetTimeOneMs();
    /* */
    
    //
    SonarInit(SONAR1);
    SonarInit(SONAR2);
    SonarInit(SONAR3);
    
    IRInit();
    
    CompassSenorInit();
    
    
    
    ColorInit(COLORSENOR1);
    ColorInit(COLORSENOR2);
    
    
    pinMode(BATTERYPIN, INPUT); //VOTAGLE 
    pinMode(38, OUTPUT);        //LOWPOWER LED
    
    digitalWrite(LED1,HIGH);
    digitalWrite(LED2,HIGH);
    
    EepromRead(VERSIONADD,&gHWVersion,sizeof(gHWVersion));
    
    
}
//////////////////////////////////////////////////SmartBotmMovment////////////////////////////////////////
/*********************************************************************************************************
** Function name:       SmartBotSetMovment
** Descriptions:        Set Movement Direction and Speed
** Input parameters:    int dir(FRONT,BACK,RIGHT,LEFT),int speed(value<=255)
** Output parameters:   none
** Returned value:      none
*********************************************************************************************************/
int SmartBotSetMovment(int dir,int speed)
{
    digitalWrite(4, HIGH);
    delay(50);
    switch(dir){
        case FRONT:  
            MotorR(speed);
            MotorL(speed);
        break;
        case BACK: 
            MotorR(-speed);
            MotorL(-speed);
        break;
        case RIGHT:  
            MotorR(speed);
            MotorL(0);
        break;
        case LEFT:
            MotorR(0);
            MotorL(speed);
        break;
        default:
        break;
    }
    return 0;
}
/*********************************************************************************************************
** Function name:       SmartBotSetMotor
** Descriptions:        Set Motor R&L 
** Input parameters:    int mode(SPEED、POWER),int port(MOTORR,MOTORL),int speed(<60mm/s in SPEED or <255 in POWER)
** Output parameters:   none
** Returned value:      none
*********************************************************************************************************/
int SmartBotSetMotor(int mode,int port,int speed)
{
	speed = -speed;//45div motor
    if(mode == POWER){
        //Serial.println("POWER!");
        gSpeedMode = false;
        if(speed>255){
            speed = 255;
        }else if(speed<-255){
            speed = -255;
        }
        switch(port){
            case MOTORR:
                MotorR(speed);
            break;
            case MOTORL:
                MotorL(speed);
            break;
            default:
            break;
        }
    }else if(mode == SPEED){
        //Serial.println("INITSPEED!");
        gSpeedMode = true;
        switch(port){
            case MOTORR:
                gPIR.target = speed;
            break;
            case MOTORL:
                gPIL.target = speed;
            break;
            default:
            break;
        }
    }
    
    return 0;
}
/*********************************************************************************************************
** Function name:       SmartBotSetMotorPI
** Descriptions:        Set Motor PI
** Input parameters:    float KP,float KI
** Output parameters:   none
** Returned value:      none
*********************************************************************************************************/
int SmartBotSetMotorPI(float KP,float KI)
{
    kp = KP;
    ki = KI;
    return 0;
}
/*********************************************************************************************************
** Function name:       SmartBotGetMotorPose
** Descriptions:        Get MotorPose R&L
** Input parameters:    int port(MOTORR,MOTORL)
** Output parameters:   none
** Returned value:      none
*********************************************************************************************************/
float SmartBotGetMotorPose(int port)
{
    switch(port){
        case MOTORR:
            return gCounterR;
        break;
        case MOTORL:
            return gCounterL;
        break;
        default:
        break;
    }
    return 0;
}
/**********Sonar*****************/
/*********************************************************************************************************
** Function name:       SmartBotSetSonar
** Descriptions:        Set Sonar Init
** Input parameters:    int port(SONAR1,SONAR2,SONAR3)
** Output parameters:   none
** Returned value:      none
*********************************************************************************************************/
int SmartBotSetSonar(int port)
{
      return SonarInit(port);
}
/*********************************************************************************************************
** Function name:       SmartBotGetSonar
** Descriptions:        Get Snoar Distance
** Input parameters:    int port(SONAR1,SONAR2,SONAR3)
** Output parameters:   none
** Returned value:      (float)Distance
*********************************************************************************************************/
float SmartBotGetSonar(int port)
{
      return SonarDetect(port);
}
/************IRModule****************/
/*********************************************************************************************************
** Function name:       SmartBotGetIRModulePort
** Descriptions:        Get IRModule Port valuwe
** Input parameters:    int port(IR1,IR2,IR3,IR4,IR5,IR6)
** Output parameters:   none
** Returned value:      valure
*********************************************************************************************************/
int SmartBotGetIRModulePort(int port)
{
     return IRDetectPort(port);
}
/*********************************************************************************************************
** Function name:       SmartBotGetIRModulePort
** Descriptions:        Get IRModule valuwe
** Input parameters:    none
** Output parameters:   none
** Returned value:      valure(bit0-6 to IR1-6)
*********************************************************************************************************/
int SmartBotGetIRModuleValue()
{
    return IRDetect();
}
/*********************************************************************************************************
** Function name:       SmartBotGetCompass
** Descriptions:        Get Compass Angle
** Input parameters:    none
** Output parameters:   none
** Returned value:      Angle
*********************************************************************************************************/
float SmartBotGetCompass()
{
    return CompassSenorDetect();
}
/*********************************************************************************************************
** Function name:       SmartBotSetCompassCalibration
** Descriptions:        Set Calibration
** Input parameters:    none
** Output parameters:   none
** Returned value:      none
*********************************************************************************************************/
void SmartBotSetCompassCalibration()
{
  CompassSenorCalibration();
}
/*********************************************************************************************************
** Function name:       SmartBotSetColorWB
** Descriptions:        Set ColorSenor White Balance
** Input parameters:    Color Senor Port
** Output parameters:   none
** Returned value:      none
*********************************************************************************************************/
int SmartBotSetColorWB(int port)
{
    ColorWB(port);
}
/*********************************************************************************************************
** Function name:       SmartBotSetColorSenor
** Descriptions:        Set ColorSenor Init or Deinit
** Input parameters:    int port,bool ison
** Output parameters:   none
** Returned value:      none
*********************************************************************************************************/
int SmartBotSetColorSenor(int port,bool ison)
{
    if(ison){
        ColorInit(port);
    }else{
        ColorDeinit(port);
    } 
}
/*********************************************************************************************************
** Function name:       SmartBotGetColorSenor
** Descriptions:        Get ColorSenor Value
** Input parameters:    int port(COLORSENOR1,COLORSENOR2),int color(RCOLOR,GCOLOR,BCOLOR)
** Output parameters:   none
** Returned value:      Color Value
*********************************************************************************************************/
int SmartBotGetColorSenor(int port,int color)
{
    switch(port){
       case COLORSENOR1:
            switch(color){
                case RCOLOR:
                    return gColorCounter1[RCOLOR];
                break;
                case GCOLOR:
                    return gColorCounter1[GCOLOR];
                break;
                case BCOLOR:
                    return gColorCounter1[BCOLOR];
                break;
                default:
                break;
            }
        break;
        case COLORSENOR2:
            switch(color){
                case RCOLOR:
                    return gColorCounter2[RCOLOR];
                break;
                case GCOLOR:
                    return gColorCounter2[GCOLOR];
                break;
                case BCOLOR:
                    return gColorCounter2[BCOLOR];
                break;
                default:
                break;
            }
        break;
        default:
        break;
    }
}
/*********************************************************************************************************
** Function name:       SmartBotSetKeyInit
** Descriptions:        Set Key Init
** Input parameters:    none
** Output parameters:   none
** Returned value:      none
*********************************************************************************************************/
int SmartBotSetKeyInit()
{
    pinMode(PINSW1,INPUT);
    pinMode(PINSW2,INPUT);
    pinMode(PINSW3,INPUT);
}
/*********************************************************************************************************
** Function name:       SmartBotGetKeyValue
** Descriptions:        Get Key Value
** Input parameters:    int key(SW1,SW2,SW3)
** Output parameters:   none
** Returned value:      none
*********************************************************************************************************/
int SmartBotGetKeyValue(int key)
{
    switch(key){
        case SW1:
            return digitalRead(PINSW1);
        break;
        case SW2:
            return digitalRead(PINSW2);
        break;
        case SW3:
            return digitalRead(PINSW3);
        break;
        default:
        break;
    }
}
/*********************************************************************************************************
** Function name:       SmartBotGetLightAnalog
** Descriptions:        Get Photoresistance Value
** Input parameters:    none
** Output parameters:   none
** Returned value:      none
*********************************************************************************************************/
int SmartBotGetLightAnalog()
{
    return analogRead(A8);
}
/*********************************************************************************************************
** Function name:       SmartBotSetLED
** Descriptions:        SetLED
** Input parameters:    port(LED1/LED2),state(ON/OFF/BLINK)
** Output parameters:   none
** Returned value:      none
*********************************************************************************************************/
int SmartBotSetLED(int port,int state)
{
    switch(port){
        case LED1:
            gLED1State = state;
        break;
        case LED2:
            gLED2State = state;
        break;
        default:
        break;
    }
    return 0;
}

/*********************************************************************************************************
** Function name:       SmartBotSetSonarThreshold
** Descriptions:        SetSonarThreshold
** Input parameters:    int dis(cm)
** Output parameters:   none
** Returned value:      none
*********************************************************************************************************/
int SmartBotSetSonarThreshold(int dis)
{
    gSonarTime = (int)(dis *58);
}