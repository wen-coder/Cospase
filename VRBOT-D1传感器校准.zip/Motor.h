
#if 0 
#define RA    5 //PE3   11//PB5
#define RB    10//PB4

#define LA    9//PH6
#define LB    8//PH5

#define ELA   2//PE4 INT0
#define ELB   3//PE5 INT1

#define ERA   21//PD0 INT2
#define ERB   20//PD1 INT3

#endif

#define RB    5 //PE3   11//PB5
#define RA    10//PB4

#define LB    9//PH6
#define LA    8//PH5

#define ELB   2//PE4 INT0
#define ELA   3//PE5 INT1

#define ERB   21//PD0 INT2
#define ERA   20//PD1 INT3

#define EDUCATION   9
#define CONTEST     -1

extern volatile float gCounterR;
extern volatile float gLastCounterR;
extern volatile float gCounterL;
extern volatile float gLastCounterL;
extern int MotorInit();
extern int test();
extern int MotorR(int val);
extern int MotorL(int val);
extern int EncoderInit();

extern int gHWVersion ;